from . import views
from django.urls import path
urlpatterns=[
    path('',views.home,name='home'),
    path('add/', views.add, name='add'),
    path('register/', views.register, name='register'),
    path('userdata/', views.userdata, name='userdata'),
    path('view_profile/', views.view_profile, name='view_profile'),
]