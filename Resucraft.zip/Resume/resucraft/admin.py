from django.contrib import admin
from .models import Destination,UserData
# Register your models here.
admin.site.register(Destination)
admin.site.register(UserData)