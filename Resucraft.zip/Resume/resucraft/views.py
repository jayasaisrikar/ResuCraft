from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from .models import UserData
def view_profile(request):
    try:
        user_data = request.user.userdata

        return render(request, 'success.html', {'user_data': user_data})
    except UserData.DoesNotExist:
        return render(request, 'profile_not_found.html')

def userdata(request):
    if request.method == 'POST':
        user = request.user

        description = request.POST.get('desc')
        skills = request.POST.get('skills')
        projects = request.POST.get('projects')
        work_experiences = request.POST.get('work_experiences')
        education = request.POST.get('education')
        email = request.POST.get('email')
        phone = request.POST.get('phone')

        profile_picture = request.FILES.get('profile_picture')
        if profile_picture:
            fs = FileSystemStorage()
            filename = fs.save(profile_picture.name, profile_picture)


        new_data = UserData(
            user=user,
            description=description,
            skills=skills,
            projects=projects,
            work_experiences=work_experiences,
            education=education,
            contact_email=email,
            phone_number=phone,
            profile_picture=profile_picture  
        )
        new_data.save()

        return render(request, 'request.html')  

    return render(request, 'request.html')

def add(request):
    if request.method == 'POST':
        username = request.POST['name']
        password = request.POST['passw']
        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return render(request, 'request.html') 
        else:
            messages.error(request, 'Invalid credentials')
            return render(request, 'login.html')

 
    else:
        return render(request, 'login.html')


def register(request):
    if request.method == 'POST':
        username = request.POST['name']
        email = request.POST['email']
        password = request.POST['passw1']
        confpassw = request.POST['passw2']
        
        if User.objects.filter(username=username).exists():
            messages.info(request, 'Username taken')
            return render(request, 'register.html')
        if User.objects.filter(email=email).exists():
            messages.info(request, 'Email taken')
            return render(request, 'register.html')
        if password == confpassw:
            user = User.objects.create_user(username=username, password=password, email=email)
            auth.login(request, user)  
            return render(request, 'login.html') 
        else:
            messages.error(request, 'Passwords do not match')
            return render(request, 'register.html')

    return render(request, 'register.html')

def home(request):

    return render(request,'login.html')
