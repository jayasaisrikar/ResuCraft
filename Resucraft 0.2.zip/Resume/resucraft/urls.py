from . import views
from django.urls import path
urlpatterns=[
    path('',views.home,name='home'),
    path('login/', views.login, name='login'),
    path('register/', views.register, name='register'),
    path('userdata/', views.userdata, name='userdata'),
    path('view_profile/', views.view_profile, name='view_profile'),

]