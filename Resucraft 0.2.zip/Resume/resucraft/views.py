from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from .models import UserData
def view_profile(request):
    try:
        user_data = request.user.userdata

        return render(request, 'result.html', {'user_data': user_data})
    except UserData.DoesNotExist:
        return render(request, 'profile_not_found.html')
from django.shortcuts import render, redirect
from .models import UserData, Skill, Language, Expertise, ComputerSkill, Institution, Job, Link
from django.core.files.storage import FileSystemStorage

def userdata(request):
    if request.method == 'POST':
        # Extract data from the form
        user = request.user
        name = request.POST.get('name')
        description = request.POST.get('desc')
        projects = request.POST.get('projects')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        address = request.POST.get('address')

        # Retrieve skills, languages, expertises, computer skills, education, and links
        skills = request.POST.getlist('skills[]')
        skill_percentages = request.POST.getlist('skill_percentages[]')
        languages = request.POST.getlist('languages[]')
        expertises = request.POST.getlist('expertises[]')
        computer_skills = request.POST.getlist('computer_skills[]')
        institutions = request.POST.getlist('institutions[]')
        years_studied = request.POST.getlist('years_studied[]')
        job_names = request.POST.getlist('job_names[]')
        job_durations = request.POST.getlist('job_durations[]')
        job_descriptions = request.POST.getlist('job_descriptions[]')
        link_names = request.POST.getlist('link_names[]')
        links = request.POST.getlist('links[]')

        # Save the uploaded profile picture
        profile_picture = request.FILES.get('profile_picture')
        if profile_picture:
            fs = FileSystemStorage()
            filename = fs.save(profile_picture.name, profile_picture)

        # Create a new UserData instance and save it
        new_data = UserData(
            user=user,
            name_of_user=name,
            description=description,
            projects=projects,
            contact_email=email,
            phone_number=phone,
            profile_picture=profile_picture,
            address=address
        )
        new_data.save()

        # Add skills to the UserData instance
        for i in range(len(skills)):
            skill_name = skills[i]
            if i < len(skill_percentages):
                skill_percentage = skill_percentages[i]
            else:
                skill_percentage = 0  # Default value if not provided
            skill, created = Skill.objects.get_or_create(skill=skill_name, percentage=skill_percentage)
            new_data.skills.add(skill)

        # Add languages to the UserData instance
        for language_name in languages:
            language, created = Language.objects.get_or_create(name=language_name)
            new_data.languages.add(language)

        # Add expertises to the UserData instance
        for expertise_name in expertises:
            expertise, created = Expertise.objects.get_or_create(name=expertise_name)
            new_data.expertises.add(expertise)

        # Add computer skills to the UserData instance
        for computer_skill_name in computer_skills:
            computer_skill, created = ComputerSkill.objects.get_or_create(name=computer_skill_name)
            new_data.computer_skills.add(computer_skill)

        # Add education to the UserData instance
        for i in range(len(institutions)):
            institution_name = institutions[i]
            if i < len(years_studied):
                years_studied_value = years_studied[i]
            else:
                years_studied_value = ''  # Default value if not provided
            institution, created = Institution.objects.get_or_create(name=institution_name, years_studied=years_studied_value)
            new_data.education.add(institution)

        # Add jobs to the UserData instance
        for i in range(len(job_names)):
            job_name = job_names[i]
            if i < len(job_durations):
                job_duration = job_durations[i]
            else:
                job_duration = ''  # Default value if not provided
            if i < len(job_descriptions):
                job_description = job_descriptions[i]
            else:
                job_description = ''  # Default value if not provided
            job, created = Job.objects.get_or_create(name=job_name, duration=job_duration, description=job_description)
            new_data.work_experiences.add(job)

        # Add links to the UserData instance
        for i in range(len(link_names)):
            link_name = link_names[i]
            if i < len(links):
                link_value = links[i]
            else:
                link_value = ''  # Default value if not provided
            link, created = Link.objects.get_or_create(name=link_name, link=link_value)
            new_data.links.add(link)

        # Redirect to a success page or render a success message
        return render(request, 'request.html')

    # Render the user data form
    return render(request, 'request.html')



def login(request):
    if request.method == 'POST':
        username = request.POST['name']
        password = request.POST['passw']
        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            return render(request, 'request.html') 
        else:
            messages.error(request, 'Invalid credentials')
            return render(request, 'login.html')

 
    else:
        return render(request, 'login.html')
        
def register(request):
    if request.method == 'POST':
        username = request.POST['name']
        email = request.POST['email']
        password = request.POST['passw1']
        confpassw = request.POST['passw2']
        if User.objects.filter(username=username).exists():
            messages.info(request, 'Username taken')
            return render(request, 'register.html')
        if User.objects.filter(email=email).exists():
            messages.info(request, 'Email taken')
            return render(request, 'register.html')
        if password == confpassw:
            user = User.objects.create_user(username=username, password=password, email=email)
            auth.login(request, user)  
            return render(request, 'login.html') 
        else:
            messages.error(request, 'Passwords do not match')
            return render(request, 'register.html')

    return render(request, 'register.html')

def home(request):

    return render(request,'home.html')
# views.py
# views.py