from django.contrib import admin
from .models import UserData,Skill

admin.site.register(UserData)
admin.site.register(Skill)